﻿namespace _02.BankOfKurtovoKonare
{
    enum Customer
    {
        Individual,
        Company
    }
}
