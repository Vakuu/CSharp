﻿namespace _02.BankOfKurtovoKonare
{
    interface IWithdraw
    {
        void Withdraw(decimal withdrawAmmount);
    }
}
