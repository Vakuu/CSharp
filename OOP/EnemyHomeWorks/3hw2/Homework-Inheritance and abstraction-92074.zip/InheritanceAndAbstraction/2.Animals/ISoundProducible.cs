﻿namespace _2.Animals
{
    public interface ISoundProducible
    {
       string ProduceSound();
    }
}
