﻿namespace _3.CompanyHierarchy.Interfaces
{
    public interface IRegularEmployee : IEmployee
    {
    }
}
