﻿namespace _3.CompanyHierarchy.Interfaces
{
    public interface ICustomer : IPerson
    {
        double NetPurchaseAmount { get; set; }
    }
}
