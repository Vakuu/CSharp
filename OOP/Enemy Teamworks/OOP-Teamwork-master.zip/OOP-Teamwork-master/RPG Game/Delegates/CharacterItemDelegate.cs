﻿namespace RPG_Game.Delegates
{
    using RPG_Game.Items;

    public delegate void CharacterItemDelegate(Item item);
}
