﻿namespace RPG_Game.Enums
{
    public enum PotionType
    {
        Health, 
        Energy
    }
}
