﻿namespace RPG_Game.Enums
{
    public enum Direction
    {
        Left, Right, Up, Down
    }
}
