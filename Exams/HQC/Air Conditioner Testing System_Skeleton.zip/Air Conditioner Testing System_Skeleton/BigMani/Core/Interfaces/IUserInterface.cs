﻿namespace BigMani.Core.Interfaces
{
    public interface IUserInterface
    {
        string ReadLine();

        void WriteLine(string message);
    }
}
