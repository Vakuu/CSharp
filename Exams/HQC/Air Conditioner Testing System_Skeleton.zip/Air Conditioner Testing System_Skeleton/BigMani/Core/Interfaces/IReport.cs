﻿namespace BigMani.Core.Interfaces
{
    interface IReport
    {
        string ToString();
    }
}
