﻿namespace BigMani.Core.Interfaces
{
    interface IAirConditioner
    {
        bool Test();
        string ToString();
    }
}
