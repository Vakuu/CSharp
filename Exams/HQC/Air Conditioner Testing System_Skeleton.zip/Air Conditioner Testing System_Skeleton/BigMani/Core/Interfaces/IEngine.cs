﻿namespace BigMani.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
