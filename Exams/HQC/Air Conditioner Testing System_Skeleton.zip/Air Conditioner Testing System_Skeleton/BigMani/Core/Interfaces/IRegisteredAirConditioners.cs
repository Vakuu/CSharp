﻿using System;
using System.Collections.Generic;

namespace BigMani.Data
{
    class IRegisteredAirConditioners
    {
        IDictionary<string, string> Models { get; }
        //void Add();
    }
}
