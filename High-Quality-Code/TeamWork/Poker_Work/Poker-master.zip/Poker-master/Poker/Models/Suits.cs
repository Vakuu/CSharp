﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poker.Models
{
    public enum Suits
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
